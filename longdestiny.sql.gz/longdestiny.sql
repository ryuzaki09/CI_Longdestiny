-- phpMyAdmin SQL Dump
-- version 2.8.0.1
-- http://www.phpmyadmin.net
-- 
-- Host: custsql-ipg06.eigbox.net
-- Generation Time: Aug 04, 2012 at 11:21 AM
-- Server version: 5.0.91
-- PHP Version: 4.4.9
-- 
-- Database: `longdestiny`
-- 

-- --------------------------------------------------------

-- 
-- Table structure for table `adminusers`
-- 

CREATE TABLE `adminusers` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(15) NOT NULL,
  `pwd` varchar(15) NOT NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

-- 
-- Dumping data for table `adminusers`
-- 

INSERT INTO `adminusers` VALUES (1, 'ryuzaki', 'C0mputer1');
INSERT INTO `adminusers` VALUES (2, 'admin', 'Pineapple01');

-- --------------------------------------------------------

-- 
-- Table structure for table `albumFolder`
-- 

CREATE TABLE `albumFolder` (
  `albumID` int(11) NOT NULL auto_increment,
  `folder_name` varchar(255) NOT NULL,
  PRIMARY KEY  (`albumID`),
  UNIQUE KEY `folder_name` (`folder_name`)
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=latin1 AUTO_INCREMENT=14 ;

-- 
-- Dumping data for table `albumFolder`
-- 

INSERT INTO `albumFolder` VALUES (1, 'My Fave Photos');
INSERT INTO `albumFolder` VALUES (3, 'My Favorite Anime');

-- --------------------------------------------------------

-- 
-- Table structure for table `albumPhotos`
-- 

CREATE TABLE `albumPhotos` (
  `pid` int(11) NOT NULL auto_increment,
  `imgname` varchar(255) NOT NULL,
  `photo_title` varchar(100) NOT NULL,
  `albumID` int(11) NOT NULL,
  PRIMARY KEY  (`pid`)
) ENGINE=MyISAM AUTO_INCREMENT=71 DEFAULT CHARSET=latin1 AUTO_INCREMENT=71 ;

-- 
-- Dumping data for table `albumPhotos`
-- 

INSERT INTO `albumPhotos` VALUES (32, '8dc1d88771f3a15ff68c4413c003506c.png', 'Death Note', 3);
INSERT INTO `albumPhotos` VALUES (36, '25b9e67fe2c1711ba9f8d8e10b129b75.jpg', 'Dr Slump - Arale 03', 1);
INSERT INTO `albumPhotos` VALUES (35, 'bc7ed8f35043f516ff0170e9000e0e66.jpg', 'Dr Slump - Arale 02', 1);
INSERT INTO `albumPhotos` VALUES (34, 'a77b30fa399956e1af871e3d580d24a5.jpg', 'Dr Slump - Arale 01', 1);
INSERT INTO `albumPhotos` VALUES (33, '439422577016293e0903987980ae3814.png', 'Death Note', 3);
INSERT INTO `albumPhotos` VALUES (37, 'f9781bb58fc5598e36e313f47db5f0a9.jpg', 'Dr Slump - Arale 04', 1);
INSERT INTO `albumPhotos` VALUES (38, '0f141b450830705eabae074bd1fb1fad.jpg', 'Bleach - Hyori 01', 1);
INSERT INTO `albumPhotos` VALUES (39, '99915eca45b683b96d60f70feb6ed4d1.jpg', 'Bleach - Hyori 02', 1);
INSERT INTO `albumPhotos` VALUES (40, 'da5dfe13c1703dcb1c0849a13bddeb47.jpg', 'Bleach - Hyori 03', 1);
INSERT INTO `albumPhotos` VALUES (41, '66eb3908bd98d86c1ee0f4d28ac9477e.jpg', 'Bleach - Hyori 04', 1);
INSERT INTO `albumPhotos` VALUES (42, '88d803442e0fed8fc2208a8fb16a7027.jpg', 'Naruto', 3);
INSERT INTO `albumPhotos` VALUES (43, '87c8609242a9f8dd737f7ebfac908cc0.jpg', 'Katekyo Hitman Reborn - Sawada Tsunayoshi', 3);
INSERT INTO `albumPhotos` VALUES (44, 'f0b9e2c34595abdc0507fa11dd0672af.jpg', 'Fairy Tail', 3);
INSERT INTO `albumPhotos` VALUES (45, '2e44db681ef9850700f9046e04f6170d.jpg', 'Fairy Tail - Lucy & Natsu', 3);
INSERT INTO `albumPhotos` VALUES (46, '12723716448619427ef30d1becf7ec51.jpg', 'One Piece', 3);
INSERT INTO `albumPhotos` VALUES (47, '238cdfdc5e1cc1bb4943411355e39f4a.jpg', 'Katekyo Hitman Reborn!', 3);
INSERT INTO `albumPhotos` VALUES (48, 'a661ff21b7eba19881453941d6f79aaf.jpg', 'One Piece', 3);
INSERT INTO `albumPhotos` VALUES (49, '8c6b25473b1e32f3acb2f6d35e33aacc.jpg', 'Katekyo Hitman Reborn!', 3);
INSERT INTO `albumPhotos` VALUES (51, 'def3df9252e0b4926b6d3fd113390515.jpg', 'Naruto Figure - 01', 1);
INSERT INTO `albumPhotos` VALUES (52, 'fa78756dfb26e1f17f489cc0a2ab0d95.jpg', 'Naruto Figure - 02', 1);
INSERT INTO `albumPhotos` VALUES (53, '2d7a8a7681e8feeaea8f6548b3a94139.jpg', 'Naruto Figure - 03', 1);
INSERT INTO `albumPhotos` VALUES (54, 'f9424ad3e9f8c34b3646445e6a2f043d.jpg', 'Naruto Figure - 04', 1);
INSERT INTO `albumPhotos` VALUES (55, '7e179a2b5981fde715b70d135b0f1e5f.jpg', 'Naruto Figure - 05', 1);
INSERT INTO `albumPhotos` VALUES (56, '66e5d405cf19e60bb554a2c19a20f2bd.jpg', 'Naruto Figure - 06', 1);
INSERT INTO `albumPhotos` VALUES (57, '429f047daca1b631f935157ed5b7bcbe.jpg', 'Naruto Figure - 07', 1);
INSERT INTO `albumPhotos` VALUES (58, '14ab9e6748638309f5bb63c3531cf5be.jpg', 'Dr Slump - Gacchan', 1);
INSERT INTO `albumPhotos` VALUES (59, '107b2703bed2040ca5e09a4681fb7dc2.jpg', 'Dr Slump - Arale (Mono)', 1);
INSERT INTO `albumPhotos` VALUES (70, '891ac520a9661d16ed71570c282d4fd6.jpg', 'Slam Dunk - Rukawa', 1);
INSERT INTO `albumPhotos` VALUES (65, '2de6e049ae9018eee1428a158a185773.jpg', 'One Piece - Nami', 1);
INSERT INTO `albumPhotos` VALUES (66, '5d340f3db4ad072f14bcbc6dd12d7908.jpg', 'One Piece - Nami', 1);
INSERT INTO `albumPhotos` VALUES (67, '36b12b7299f697ab00eb4ef7349dc09c.jpg', 'One Piece - Nami', 1);
INSERT INTO `albumPhotos` VALUES (68, '82245ff5eb589d56d25acec2776a54d6.jpg', 'Slam Dunk - Rukawa', 1);
INSERT INTO `albumPhotos` VALUES (69, '49ddce278d79317844cca157f04129f3.jpg', 'Slam Dunk - Rukawa', 1);

-- --------------------------------------------------------

-- 
-- Table structure for table `blogposts`
-- 

CREATE TABLE `blogposts` (
  `id` int(11) NOT NULL auto_increment,
  `title` varchar(100) NOT NULL,
  `desc` text NOT NULL,
  `images` varchar(150) NOT NULL default 'no_image',
  `date` date NOT NULL,
  `vid_id` varchar(50) NOT NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `title` (`title`)
) ENGINE=MyISAM AUTO_INCREMENT=29 DEFAULT CHARSET=latin1 AUTO_INCREMENT=29 ;

-- 
-- Dumping data for table `blogposts`
-- 

INSERT INTO `blogposts` VALUES (1, 'Currently Under Construction', 'This is a nightmare. I will update again soon.', '', '2011-05-25', '');
INSERT INTO `blogposts` VALUES (2, 'IT''S UP!', 'Well, after days and days of work.. the site is still not fully working.. There''s still work or improvements left to do of course.<br/>I will continue to post on the website to keep an update.<p>Watch this space!</p>', '', '2011-05-26', '');
INSERT INTO `blogposts` VALUES (3, 'Contact Form!', 'The contact form is now ready!<br/>Please feel free to fill out the form to send me any messages/comments!<br/>Many Thanks!', '', '2011-05-26', '');
INSERT INTO `blogposts` VALUES (4, 'IGNORE - Twitter navigation!', 'Please ignore the Twitter window on the right side as that is currently still being worked on.<p>Will update once it''s ready!</p>', '1306763530twitter.png', '2011-05-26', '');
INSERT INTO `blogposts` VALUES (5, 'London MCM Expo 27th - 29th 2011!', 'It''s that time of year again!<br/>For anyone who doesn''t know, this is an event which is held at London Excel twice every year. It''s a very popular event which involves Movies Comics and Media as the name abbreviates. People from national and international travel all the way here to attend this particular event.<p>Why would they do this, you ask? Well, the main attraction of this event is the people who dress up in costumes (could be from a movie, but mainly it''s from Anime) and roleplaying as that character. This is known as Cosplay. There are many many people who cosplay through the days of this event because it''s fun and you get alot of people wanting to take pictures with you.</p>I cosplayed once with my friends last year, it was really fun. Wanted to do it this week, but my friends were too busy and didn''t have enough time to get costumes.. oh well. There''s another event later this year. Will cosplay with my friends then. =)<br/>Check it out <a href=''http://www.londonexpo.com'' target=''_blank''>here</a> for more info.<p>Anyway, I should be attending to this event tomorrow, if anyone is going, send me a message!</p>', '1306763760expo.png', '2011-05-27', '');
INSERT INTO `blogposts` VALUES (6, 'Twitter Feed', 'Okay, the twitter feed on the right hand side should be working now. It displays the top 3 recent tweets that is made by me. If you discover that it is blank, please contact me!<p>Thanks!</p>', '', '2011-05-31', '');
INSERT INTO `blogposts` VALUES (7, 'Twitter Feed part 2', 'Okay, it''s not working perfectly... I''m currently still working on it. Will update again soon.', '', '2011-05-31', '');
INSERT INTO `blogposts` VALUES (9, 'Test Post with Youtube Video!', 'Youtube video test', '', '2011-06-01', 'IjDPzRe02iQ');
INSERT INTO `blogposts` VALUES (10, 'Higher - Taio Cruz ft. Kylie Minogue', 'Okay the youtube video seems to be working now.<br/>Here''s another video just for the post. =)', '', '2011-06-01', 'KRBS5WZMdik');
INSERT INTO `blogposts` VALUES (13, 'Twitter Feed part 3', 'It''s working now!! *phew* =)', '1307437814twitter11.jpg', '2011-06-07', '');
INSERT INTO `blogposts` VALUES (15, 'Call of Duty: Black Ops - Escalation', 'Ok, so this isn''t really new since it''s been out on Xbox360 for a month now. But it''s finally out on PS3!! For me it''s great because I''m a PS3 player rather than Xbox360. <br/>You probably know already but I''ll say it anyway, the map pack includes 5 different maps that are called ''Convoy'', ''Zoo'', ''Hotel'', ''Stockpile'' and the Zombie map ''Call of the Dead''.<p>I''m not particularly pro on this game but I''m good with the zombie maps though!</p>For more information, header over to the <a href=''http://www.callofduty.com'' target=''_blank''>Call of Duty</a> Website.', '1307698023Black-Ops-Escalation.jpg', '2011-06-10', '');
INSERT INTO `blogposts` VALUES (19, 'Double Quote - Test', '\\&quot;This is a test for double quotes\\&quot;.<br />\r\n\\&quot;Please Ignore this\\&quot;.', '', '2011-06-12', '');
INSERT INTO `blogposts` VALUES (20, 'OMG!! Line Break and Double Quote - Problem Solved!!', 'I have finally solved the stupid line break and the double quote problem!!<br />\r\nIt was driving me mad!!! Originally I had to use the HTML line break tag to put text into a new line but now i don\\''t have to do that!<br />\r\nI can just press the RETURN key to do that now with the help of the \\&quot;nl2br\\&quot; function. =)<br />\r\nI did try a few other functions before this but it didn\\''t quite work for me. Things kept going wrong here and there and then I left the problem for a little while. Now I came back to the problem, without spending more than an hour I have solved the problem!! *phew*.<br />\r\n <br />\r\nAnd with the double quote issue I had to use \\&quot;str_replace\\&quot; function to replace the double quotes with the HTML entity, because originally it would just break the hyperlink and the SQL query if the double quotes were included. I tried and tried, testing for quite a while and finally it\\''s all SOLVED!!! <br />\r\nJust so happy!!!! =)', '1307891012ProblemSolved.png', '2011-06-12', '');
INSERT INTO `blogposts` VALUES (21, 'Comments under construction', 'I\\''m currently working on the comments section so people can leave comments for posts that I\\''ve added.<br />\r\n<br />\r\nI will update again once it\\''s ready!<br />\r\nWatch this space!! =)', '', '2011-06-12', '');
INSERT INTO `blogposts` VALUES (22, 'Comments Section - Complete!', 'Wow.. didn\\''t take me a week, probably 4 or 5 days.. with lots of breaks in between of course.. i finally finished the comments section!<br />\r\nEncountered quite a few problems along the way, but I\\''m glad it\\''s working now. =)<br />\r\n<br />\r\nPlease feel free to leave comments!! =D', '1308219744Finished.jpg', '2011-06-16', '');
INSERT INTO `blogposts` VALUES (23, 'Call of Duty Black Ops - Annihilation - Xbox360', 'Good news for all Call of Duty fans!! (Well for Xbox360 users anyway)<br />\r\nAfter a recent map pack release of the Escalation map pack, Treyarch has yet again been working hard and pushing their limits to the max to release another DLC called \\&quot;Annihilation\\&quot;.<br />\r\nThis map pack contains 5 maps in total, \\''Hangar 18\\'', \\''Silo\\'', \\''Drive-in\\'', \\''Hazard\\'' and another Zombie Map \\''Shangri-La\\''.<br />\r\nAgain, the map pack will be released for Xbox360 first on the June 28th and then more than likely a month later for the PC and PS3.<br />\r\n<br />\r\nFor more info, screenshots and videos, head over to the <a href=\\''http://www.callofduty.com/blackops\\'' target=\\''_blank\\''>Call of Duty</a> Website.', '1308480481black-ops-annihilation.jpg', '2011-06-19', '');
INSERT INTO `blogposts` VALUES (24, 'Call of Duty Black Ops - Annihilation Preview', 'Just thought I add the video here if anyone wants to take a look. =)', '', '2011-06-19', 'r1bwnAHNRtw');
INSERT INTO `blogposts` VALUES (25, 'Team Fortress 2! FREE!!!', 'For anyone who likes FPS (First Person Shooter) games, they should definitely consider this. The fact that it\\''s now FREE to play.. yes you read right, it\\''s FREE!!!<br />\r\n<br />\r\nValve have announced that it\\''s going to be free forever, no limits, play as much as you like!!<br />\r\nFor people who have bought this game before it was released as free, their accounts will become premium accounts which will include extra features.<br />\r\nThe graphics for this isn\\''t anything like as say \\''Call of Duty\\'' but the gameplay is without a doubt awesome. Many have said that this is one of the best FPS game currently available and was praised about the graphical style and gameplay balance.<br />\r\nCheck out the short clip here! =)', '', '2011-06-28', 'eQ8duKs2Plw');
INSERT INTO `blogposts` VALUES (26, 'Work In Progress!', 'Haven\\''t post an update for a while.. Well it\\''s because I\\''ve been working on another website for a client. I\\''m building his site with <a href=\\''http://wordpress.org\\'' target=\\''_blank\\''>WordPress</a> and it\\''s the first time for me so I\\''ve put in everything I got into design and develop the site.<br />\r\nInstead of using the themes or WordPress\\''s structured layout, I have changed the style and layout completely by modifying the PHP and CSS files.<br />\r\n<br />\r\nAnyway, I\\''m not going to disclose too much about the site as it\\''s still under construction. Once it\\''s ready, I will update again! =)', '1311791695workinprog.jpg', '2011-07-27', '');
INSERT INTO `blogposts` VALUES (27, 'Survival Armageddon', 'Well.. the site that I been working on is pretty much finished. Been on and off on it for a while because had to go back and forth with the client for many different things.<br />\r\nAnyway, the site is based on a survival guide for people to get information on how they can survive natural disasters of the world. It talks about Flood, Tornados, Volcanos etc.. etc.. and what you need to do to survive this.<br />\r\n<br />\r\nThe site is created in <a href=\\''http://wordpress.org\\'' target=\\''_blank\\''>WordPress</a> and I created custom CSS layouts which inlcudes JavaScript/Jquery. I did this going into the code of the PHP files in <a href=\\''http://wordpress.org\\'' target=\\''_blank\\''>WordPress</a> and modified the code here and there.<br />\r\nEnough babbling... here\\''s the site, <a href=\\''http://www.survivalarmageddon.com\\'' target=\\''_blank\\''>Survival Armageddon</a>.', '', '2011-09-07', '');
INSERT INTO `blogposts` VALUES (28, 'New Site!', 'I\\''m planning to redesign the website and it\\''s going to take quite some time... <br />\r\nAnyway will post another update soon when I have time...', '', '2011-12-11', '');

-- --------------------------------------------------------

-- 
-- Table structure for table `fpphotos`
-- 

CREATE TABLE `fpphotos` (
  `photoID` int(11) NOT NULL auto_increment,
  `foldername` varchar(255) NOT NULL default 'frontpage',
  `imgname` varchar(255) NOT NULL,
  `windowID` int(11) NOT NULL,
  PRIMARY KEY  (`photoID`)
) ENGINE=MyISAM AUTO_INCREMENT=52 DEFAULT CHARSET=latin1 AUTO_INCREMENT=52 ;

-- 
-- Dumping data for table `fpphotos`
-- 

INSERT INTO `fpphotos` VALUES (49, 'thumbs', 'contact.jpg', 41);
INSERT INTO `fpphotos` VALUES (41, 'thumbs', 'bleach01.png', 41);
INSERT INTO `fpphotos` VALUES (29, 'thumbs', 'aboutme01.jpg', 38);
INSERT INTO `fpphotos` VALUES (51, 'thumbs', '2.jpg', 49);
INSERT INTO `fpphotos` VALUES (44, 'thumbs', '8.jpg', 49);
INSERT INTO `fpphotos` VALUES (46, 'thumbs', 'me02.jpg', 38);
INSERT INTO `fpphotos` VALUES (47, 'thumbs', 'gacchan01.jpg', 48);
INSERT INTO `fpphotos` VALUES (48, 'thumbs', 'arale01.jpg', 48);

-- --------------------------------------------------------

-- 
-- Table structure for table `frontpage`
-- 

CREATE TABLE `frontpage` (
  `id` int(11) NOT NULL auto_increment,
  `title` varchar(255) NOT NULL,
  `sub_title` varchar(255) NOT NULL,
  `desc1` varchar(255) NOT NULL,
  `desc2` mediumtext NOT NULL,
  `image` varchar(255) NOT NULL default 'noimage',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `title` (`title`)
) ENGINE=MyISAM AUTO_INCREMENT=50 DEFAULT CHARSET=latin1 AUTO_INCREMENT=50 ;

-- 
-- Dumping data for table `frontpage`
-- 

INSERT INTO `frontpage` VALUES (38, 'About Me', 'PHP Developer', 'A PHP developer who''s keen and passionate and always looking forward to learning new technologies.', 'I.T Background: \nI''ve previously come from an IT Networking/Support environment and I''ve developed a great amount of skills and knowledge from the previous jobs I have worked for and courses that I took. Having worked in this field for 4 years, this ended for me in Dec 2010. Since then I went on to pursue a Web Design & Development career.\n\nI specialise in these technologies, PHP w/ MySQL, MVC Framework Codeigniter, AJAX, Javascript, Jquery, HTML/XHTML, CSS and I''ve been involved with a project that uses WordPress.', '31.jpg');
INSERT INTO `frontpage` VALUES (48, 'Photos', 'Past & Present', 'Gallery of my favourite Photos.\nEnjoy! =)', 'Gallery of my favourite <a href="photos">Photos</a>.\nEnjoy! =)', '8.jpg');
INSERT INTO `frontpage` VALUES (41, 'Contact', 'Send Me a MSG', 'If you have any questions, send me a message and I''ll get back to you as soon as I can. =)', 'If you have any questions, send me a message and I''ll get back to you as soon as I can. =)', '5.jpg');
INSERT INTO `frontpage` VALUES (49, 'Portfolio', 'Concept, Design & Print', 'A gallery of my previous work, please check it out!', 'A gallery of my previous work, please check it out!\n<a href="portfolio">My Portfolio</a>\n', '7.jpg');

-- --------------------------------------------------------

-- 
-- Table structure for table `portfolio`
-- 

CREATE TABLE `portfolio` (
  `port_id` int(11) NOT NULL auto_increment,
  `port_img` varchar(255) NOT NULL,
  `port_title` varchar(100) NOT NULL,
  `port_link` varchar(255) NOT NULL,
  `position` int(11) default NULL,
  PRIMARY KEY  (`port_id`)
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=latin1 AUTO_INCREMENT=17 ;

-- 
-- Dumping data for table `portfolio`
-- 

INSERT INTO `portfolio` VALUES (15, '5839a449285b9c3ae1c0cac44c82633c.jpg', 'Don''t Panic - Video Page', 'www.dontpaniconline.com/video', 8);
INSERT INTO `portfolio` VALUES (14, '353da947d869e182c04f63ff47316907.jpg', 'Don''t Panic - CMS', 'www.dontpaniconline.com', 6);
INSERT INTO `portfolio` VALUES (16, 'd0983d1f66fe373981f8e471ffeb674a.jpg', 'Don''t Panic - Front Page', 'www.dontpaniconline.com', 10);

-- --------------------------------------------------------

-- 
-- Table structure for table `postcomments`
-- 

CREATE TABLE `postcomments` (
  `id` bigint(20) NOT NULL auto_increment,
  `name` varchar(20) NOT NULL,
  `email` varchar(75) NOT NULL,
  `post_comm` text NOT NULL,
  `post_id` bigint(20) NOT NULL,
  `comm_date` datetime NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

-- 
-- Dumping data for table `postcomments`
-- 

INSERT INTO `postcomments` VALUES (7, 'unknown', 'unknown@gmail.com', 'Well Done!!! =)', 22, '2011-06-16 13:36:48');
INSERT INTO `postcomments` VALUES (6, 'WAHHHHHHHH', 'satan@hell.com', 'La la la la la....<br />\r\nTesting testing...', 22, '2011-06-16 13:36:43');
INSERT INTO `postcomments` VALUES (5, 'Annonymous', 'unknown@hotmail.com', 'Keep it up!!', 21, '2011-06-16 12:34:37');
INSERT INTO `postcomments` VALUES (8, 'wai', 'really?@didyoucheck.com', 'well done!', 20, '2011-06-17 17:00:49');
